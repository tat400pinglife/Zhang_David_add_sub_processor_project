Hello!

Attached are the following files:
- Word document of report
- PowerPoint file of presentation shown in video 
- TWO video files, they are identical except one is a MP4 and the other is MKV (I didn't know what format you wanted)
- Archived project file, (.QAR file)
- Folder containing all VHD files

To run project, open archived project file and choose where to unpack all VHD files and compile as normal
OR attached as well is a folder containing VHD files, make new project in Quartus and add files manually to project

I have tried both methods and have got them to compile and generate a RTL view

To get waveforms, compile all project files in Modelsim and simulate the testbench file

**NOTE: There is a small bug/glitch when compiling in Modelsim where the package gets compiled last,
 all you have to do is compile it again to fix it **

**NOTE: to get a complete waveform the simulation must run for atleast 180 ps **

That's all! Thank you for your time

- David Zhang